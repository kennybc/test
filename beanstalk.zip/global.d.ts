declare module "use-sound" {
  export default function useSound(sound: any, options?: any): any;
}
