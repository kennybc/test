const Loser = () => {
  return <div>loser</div>;
};

export default Loser;
